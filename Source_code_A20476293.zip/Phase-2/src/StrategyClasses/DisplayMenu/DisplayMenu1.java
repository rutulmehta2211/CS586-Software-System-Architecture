package StrategyClasses.DisplayMenu;

import DataClasses.Data;

public class DisplayMenu1 extends DisplayMenu{

    public DisplayMenu1(Data data) {
        super(data);
    }

    @Override
    public void DisplayMenu() {
        System.out.println(">>>> Available Options: ");
        System.out.print("\n");
        System.out.print("     2. deposit(int)");
        System.out.print("\n");
        System.out.print("     3. withdraw(int)");
        System.out.print("\n");
        System.out.print("     4. balance()");
        System.out.print("\n");
        System.out.print("     6. logout()");
        System.out.print("\n");
        System.out.print("     7. lock(int)");
        System.out.print("\n");
    }
}
