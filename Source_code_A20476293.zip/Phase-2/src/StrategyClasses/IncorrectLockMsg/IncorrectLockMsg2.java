package StrategyClasses.IncorrectLockMsg;

import DataClasses.Data;

//IncorrectLockMsg2 class belongs to Account-2
public class IncorrectLockMsg2 extends IncorrectLockMsg{

    public IncorrectLockMsg2(Data data) {
        super(data);
    }

    //No operation is performed to show Incorrect Lock Message for Account-2.
    @Override
    public void IncorrectLockMsg() {
        
    }
    
}
