package StrategyClasses.NoFundsMsg;

import DataClasses.Data;

public class NoFundsMsg1 extends NoFundsMsg{

    public NoFundsMsg1(Data data) {
        super(data);
    }

    //No operation is performed to show No fund message for Account-1.
    @Override
    public void NoFundsMsg() {
        
    }
    
}
