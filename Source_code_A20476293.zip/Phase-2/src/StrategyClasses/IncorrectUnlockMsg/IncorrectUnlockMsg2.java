package StrategyClasses.IncorrectUnlockMsg;

import DataClasses.Data;

public class IncorrectUnlockMsg2 extends IncorrectUnlockMsg{

    public IncorrectUnlockMsg2(Data data) {
        super(data);
    }

    //No operation is performed to Show Incorrect unlock Message for Account-2.
    @Override
    public void IncorrectUnlockMsg() {
        
    }
    
}
