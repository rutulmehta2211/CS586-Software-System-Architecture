package StrategyClasses.Penalty;

import DataClasses.Data;

public class Penalty2 extends Penalty{

    public Penalty2(Data data) {
        super(data);
    }

    //No penalty is applied to Account-2. 
    @Override
    public void Penalty() {
        
    }
    
}
