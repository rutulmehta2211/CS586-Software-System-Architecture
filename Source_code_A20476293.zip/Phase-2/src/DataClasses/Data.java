package DataClasses;

/**
 * Data Abstract class
 */
public abstract class Data {
    
}
